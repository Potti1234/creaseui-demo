async (page) => {
  await page.goto('http://127.0.0.1:4297/');
  await page.getByRole('button',{name:'Assignee for CRE-128: Alex Morgan',exact:true}).click();
  await page.getByRole('menu',{name:'Change assignee',exact:true}).waitFor();
  const references = await page.evaluate(() => [...document.querySelectorAll('[aria-controls]')]
    .filter(e=>e.getClientRects().length > 0)
    .map(e=>({element:e.id || e.textContent.trim(),controls:e.getAttribute('aria-controls'),exists:!!document.getElementById(e.getAttribute('aria-controls'))})));
  if(references.some(r=>!r.exists)) throw new Error('Broken live aria-controls reference');
  const menuBox = await page.getByRole('menu').boundingBox();
  const viewport = page.viewportSize();
  if(menuBox.x < 0 || menuBox.y < 0 || menuBox.x + menuBox.width > viewport.width || menuBox.y + menuBox.height > viewport.height) throw new Error('Menu out of viewport');
  await page.keyboard.press('Escape');
  await page.getByRole('menu').waitFor({state:'hidden'});
  const metrics = await page.evaluate(()=>({
    rowHeights:[...new Set([...document.querySelectorAll('.issue-row')].filter(e=>e.getClientRects().length).map(e=>e.getBoundingClientRect().height))],
    header:document.querySelector('.page-header').getBoundingClientRect().height,
    toolbar:document.querySelector('.view-toolbar').getBoundingClientRect().height,
    groupHeader:document.querySelector('.group-heading').getBoundingClientRect().height,
    font:getComputedStyle(document.body).fontFamily,
    missingIcons:document.querySelectorAll('[data-icon-missing]').length,
  }));
  if(metrics.rowHeights.length !== 1 || metrics.rowHeights[0] !== 44 || metrics.missingIcons) throw new Error('Geometry/asset drift');
  return {liveAriaControls:references,menuBox,metrics};
}
