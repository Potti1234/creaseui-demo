import type { Html, HtmlBuilder } from 'foldkit/html'
import { action } from './design/primitives'
import { button } from '@/ui/button'
type Message = { readonly _tag: 'Clicked' }
export const raw = (h: HtmlBuilder<Message>): Html => h.div([h.Class('p-3')], [h.button([], ['Raw'])])
export const forged = (h: HtmlBuilder<Message>): Html => action(({ label: 'Bad', onClick: { _tag: 'Clicked' }, class: 'text-red-500' } as any), h)
export const direct = (h: HtmlBuilder<Message>): Html => button({ children: ['Wrong layer'] }, h)
