async (page) => {
  const passed = [];
  const errors = [];
  const onConsole = message => { if(message.type() === 'error') errors.push(message.text()); };
  page.on('console', onConsole);
  try {
    await page.goto('http://127.0.0.1:5197/');
    await page.getByRole('button',{name:'Display options',exact:true}).click();
    await page.getByRole('menuitemradio',{name:'Priority',exact:true}).click();
    await page.waitForFunction(()=>document.querySelector('[aria-label="In progress issues"] [data-issue-id]').getAttribute('data-issue-id') === 'CRE-121');
    passed.push('Display orders actual issues by priority within status');
    await page.getByRole('button',{name:'Display options',exact:true}).click();
    await page.getByRole('menuitemradio',{name:'Default order',exact:true}).click();
    await page.waitForFunction(()=>document.querySelector('[aria-label="In progress issues"] [data-issue-id]').getAttribute('data-issue-id') === 'CRE-128');
    for(let i=0;i<4;i++) {
      await page.getByRole('button',{name:'My issues',exact:true}).click();
      await page.getByRole('heading',{name:'My issues',exact:true}).waitFor();
      await page.getByRole('button',{name:'All issues',exact:true}).click();
      await page.getByRole('heading',{name:'All issues',exact:true}).waitFor();
    }
    passed.push('repeated personal/all navigation stays stable');
    await page.getByRole('button',{name:'New issue',exact:true}).click();
    await page.getByRole('textbox',{name:'Issue title',exact:true}).waitFor();
    await page.getByRole('button',{name:'Status for new issue: Todo',exact:true}).click();
    await page.getByRole('menu',{name:'Change status',exact:true}).waitFor();
    await page.keyboard.press('Escape');
    await page.getByRole('menu').waitFor({state:'hidden'});
    if(!await page.getByRole('dialog').isVisible()) throw new Error('Escape closed both layers');
    passed.push('Escape closes a nested picker before its composer');
    await page.keyboard.press('Escape');
    await page.getByRole('dialog').waitFor({state:'hidden'});
    await page.keyboard.press('/');
    await page.waitForFunction(()=>document.activeElement.id === 'issue-search');
    await page.keyboard.press('c');
    if(await page.locator('dialog[open]').count()) throw new Error('Typing c opened a composer');
    passed.push('search shortcut focuses the field and typing suppresses creation shortcut');
    await page.getByRole('searchbox',{name:'Search issues in this view',exact:true}).fill('no matching sample');
    await page.getByRole('heading',{name:'No issues match your view',exact:true}).waitFor();
    await page.screenshot({path:'output/issue-empty-desktop.png',scale:'css'});
    await page.getByRole('button',{name:'Clear search and filters',exact:true}).click();
    await page.getByRole('button',{name:'Reset sample workspace',exact:true}).click();
    await page.getByRole('button',{name:'Cancel',exact:true}).click();
    await page.getByRole('dialog').waitFor({state:'hidden'});
    if(await page.locator('[data-issue-id]').count() !== 15) throw new Error('Cancel reset changed data');
    passed.push('cancel reset leaves data intact');
    await page.setViewportSize({width:390,height:844});
    if(await page.evaluate(()=>document.documentElement.scrollWidth > innerWidth)) throw new Error('Page overflows at 390px');
    await page.screenshot({path:'output/issue-list-narrow.png',scale:'css'});
    passed.push('390px layout stays contained with labelled navigation');
    await page.setViewportSize({width:1440,height:900});
    await page.evaluate(()=>localStorage.setItem('crease-tasks-prototype-v1','{invalid'));
    await page.reload();
    await page.getByText('Saved data could not be read. Showing the sample workspace.',{exact:true}).waitFor();
    if(await page.locator('[data-issue-id]').count() !== 15) throw new Error('Corrupt storage did not recover');
    passed.push('invalid saved data recovers to schema-valid sample issues with a notice');
    await page.getByRole('button',{name:'Reset sample workspace',exact:true}).click();
    await page.getByRole('button',{name:'Reset sample data',exact:true}).click();
    await page.getByRole('dialog').waitFor({state:'hidden'});
    await page.getByRole('button',{name:'Dismiss notification',exact:true}).click();
    if(errors.length) throw new Error(errors.join('\n'));
    return {passed,count:passed.length,consoleErrors:errors};
  } finally { page.off('console', onConsole); }
}
