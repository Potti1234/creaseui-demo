async (page) => {
  const reports = [];
  const audit = async (state) => {
    const result = await page.evaluate(async () => {
      const result = await axe.run(document, {runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa','wcag22aa']}});
      return {violations:result.violations.map(v=>({id:v.id,impact:v.impact,count:v.nodes.length,nodes:v.nodes.slice(0,4).map(n=>({target:n.target,summary:n.failureSummary}))})),incomplete:result.incomplete.map(v=>({id:v.id,count:v.nodes.length,nodes:v.nodes.slice(0,2).map(n=>({target:n.target,summary:n.failureSummary}))}))};
    });
    reports.push({ state, ...result });
  };
  await page.goto('http://127.0.0.1:4297/');
  await page.addScriptTag({path:'C:/Users/lpottner/Documents/MaasProjects/creaseui-reliability-review/node_modules/axe-core/axe.min.js'});
  await audit('issue-list');
  await page.getByRole('button',{name:'Assignee for CRE-128: Alex Morgan',exact:true}).click();
  await page.getByRole('menu',{name:'Change assignee',exact:true}).waitFor();
  await audit('assignee-menu');
  await page.keyboard.press('Escape');
  await page.getByRole('menu').waitFor({state:'hidden'});
  await page.getByRole('button',{name:'New issue',exact:true}).click();
  await page.getByRole('textbox',{name:'Issue title',exact:true}).waitFor();
  await audit('issue-composer');
  await page.keyboard.press('Escape');
  await page.getByRole('dialog').waitFor({state:'hidden'});
  return reports;
}

