import type { Html, HtmlBuilder } from 'foldkit/html'
export const unregistered = (h: HtmlBuilder<unknown>): Html => h.button([], ['Not an approved source file'])
