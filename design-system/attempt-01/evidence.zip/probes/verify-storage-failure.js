async (page) => {
  await page.goto('http://127.0.0.1:4297/');
  await page.getByRole('button',{name:'Status for CRE-128: In progress',exact:true}).waitFor();
  await page.evaluate(()=>{ window.originalStorageWrite = Storage.prototype.setItem; Storage.prototype.setItem = function() { throw new DOMException('Blocked for verification','QuotaExceededError'); }; });
  await page.getByRole('button',{name:'Priority for CRE-128: High',exact:true}).click();
  await page.getByRole('menuitemradio',{name:'Low',exact:true}).click();
  await page.getByText('Your changes are visible, but could not be saved in this browser.',{exact:true}).waitFor();
  await page.getByText('Changes could not be saved',{exact:true}).waitFor();
  await page.evaluate(()=>{Storage.prototype.setItem=window.originalStorageWrite; delete window.originalStorageWrite;});
  await page.reload();
  await page.getByRole('button',{name:'Priority for CRE-128: High',exact:true}).waitFor();
  const done = page.getByRole('region',{name:'Done',exact:true}).getByRole('button',{name:'Done 2',exact:true});
  await done.click();
  await page.getByRole('list',{name:'Done issues',exact:true}).waitFor();
  await done.click();
  await page.getByRole('list',{name:'Done issues',exact:true}).waitFor({state:'hidden'});
  return {passed:['write failure reports unsaved state without losing the visible edit','failed write does not falsely persist after reload','group collapse and expand works'],count:3};
}
